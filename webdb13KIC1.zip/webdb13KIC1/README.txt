Projectgroep: 	webdb13KIC1
Projectnaam: 	Roda Support Forum
Groepsleden:	Jennifer Roeting	10181733
		Kyllian Broers		10343865
		Max Bevelander		10375120
		Michael Chen		10411941
Web adres:	http://webdb.science.uva.nl/webdb13KIC1
De genoemde groepsleden (omschreven bij Groepsleden) onderschrijven dat zij allen een even groot deel
hebben bijgedragen aan het eindresultaat van het eindresultaat van het project. Daaronder valt
te verstaan: de website, de presentatie en het verslag.

Gebruikersnaam en wachtwoord voor het testen van de administrator functie:
Gebruikersnaam:	TestAdmin
Wachtwoord:	admin

Gebruikersnaam en wachtwoord voor het testen van de user functie:
Gebruikersnaam:	TestUser
wachtwoord:	user

Uiteraard valt zelf registreren onder de mogelijkheid om de functie van user te testen.

----------------------------------------------------------------------------------------------
CODE VAN DE WEBPAGINA'S
----------------------------------------------------------------------------------------------

Alle code is te vinden in het gecomprimeerde bestand codes.zip.
Dit is gedaan om een zeer onoverzichtelijk en lang tekstbestand te voorkomen.
