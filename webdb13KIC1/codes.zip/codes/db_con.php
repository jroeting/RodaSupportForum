
<?php
	// connect with database by creating new PDO
	$db = new PDO('mysql:host=localhost;dbname=webdb13KIC1', 'webdb13KIC1', 'busteqec');
?>