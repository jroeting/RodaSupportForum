<h3 class="tablehead">
	How do I register for the forum?
</h3>
<!--content -->
<div>
	Browsing the forum as a guest is possible, but then you can not post messages or start a discussion and other features are limited. <br />
	To post a message or start a discussion of your own, you must complete a one-time registration, it is free. <br />
	To register, simply click on the "register" on the top right corner of the forum page next to "login" and fill out form. <br />
	For security purposes, we require e-mail confirmation of your registration. <br />
	When you register, you must choose a unique username and you must provide a valid email address. <br />
	If the entered name and/or email address is already in use, you will be prompted to choose another one. <br />
	After you submit your form, a mail will be send for validation. <br />
	Once your e-mail address has been confirmed, you are ready to participate the forum. <br />
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>
