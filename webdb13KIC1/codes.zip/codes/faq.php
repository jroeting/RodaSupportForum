<h2 class="tablehead">
		FAQ
</h2>
<!-- content of FAQ-page-->
<div >
	<a href="index.php?content=rules"> <i> <strong> Rules </strong> </i> </a> <br /> <br />
	<a href="index.php?content=faq1">How do I register for the forum? </a> <br />
	<a href="index.php?content=faq2">How do I log into the forums? </a> <br />
	<a href="index.php?content=faq3">How do I start a new discussion? </a> <br />
	<a href="index.php?content=faq4">How do I reply to another member's message? </a> <br />
	<a href="index.php?content=faq5">How do I return to the forum directory page? </a> <br />
	<a href="index.php?content=faq6">How do I report an inappropriate or offensive message? </a> <br />
	<a href="index.php?content=faq7">Can I delete or edit my discussion postings? </a> <br />
	<a href="index.php?content=faq8">Can I use HTML codes in my discussion postings or can I stylize some of my text? </a> <br />
	<a href="index.php?content=faq9">How do I get to know more about the members who have posted in the forums? </a> <br />
	<a href="index.php?content=faq10">How can I edit/update my profile page? </a> <br />
	<a href="index.php?content=faq11">Is it possible to contact a forum member without posting a message in the forums? </a> <br />
</div>
