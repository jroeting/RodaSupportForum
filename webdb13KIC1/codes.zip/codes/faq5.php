<h3 class="tablehead">
	How do I return to the forum directory page?
</h3>
<!-- content -->
<div>
	To return to the forum directory page, simply click the "forum" button on the red main menu. <br />
	
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>