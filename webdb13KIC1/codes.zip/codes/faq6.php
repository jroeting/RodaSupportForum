<h3 class="tablehead">
	How do I report an inappropriate or offensive message?
</h3>
<!-- content -->
<div>
	If you come across a particular message in the forums that contains spam or other offensive content, <br />
	we encourage you to notify our admins by clicking "report as spam" located at each individual message. <br />
	In order to report an offensive post, you must be registered and logged in as a user. <br />
	Once reported, our admins will be notified of the message and it will be reviewed. <br />
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>