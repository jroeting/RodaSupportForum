<h3 class="tablehead">
	Can I delete or edit my discussion postings?
</h3>
<!-- content -->
<div>
	Unfortunately the answer is no, once the message is posted, it cannot be edited or deleted by the member. <br />
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>