<h3 class="tablehead">
	How do I reply to another member's message?
</h3>
<!-- content -->
<div>
	After you are logged in as a user, you are able to access the forum on the menu bar. On that page, all categories are listed as links. <br />
	After you clicked on the desired category, you can see all messages that have been made. <br />
	If you click on one of these messages, you can reply to another member's message <br />
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>