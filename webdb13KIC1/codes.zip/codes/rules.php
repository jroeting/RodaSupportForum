<h3 class="tablehead">
	Forum Rules
</h3>
<!-- content of rules -->
<div>
	<p> <i> <strong> General Rules </strong> </i> </p> 
	- <i> <b> Respect: </b> </i> respect each other's posts. Each person has his/her own opinions. No hateful messages. <br />
	- <i> <b> No Offensive Content: </b> </i> Sexually explicit or illegal activities are not allowed. <br />
	- <i> <b> No Spam/Advertising: </b> </i> Please notify an admin or moderator if you receive or see any. <br />
	- <i> <b> Use English: </b> </i> To avoid confusion among the others, please use only ENGLISH! <br />
	<br />
	
	<p> <i> <strong> Posting Rules </strong> </i> </p> 
	- <i> <b> No Double Posting: </b> </i> There is no need for double enforcement, because we ware people who van read. <br />
	- <i> <b> Use proper English: </b> </i> So don't type: "Diz iz awes0m3". <br />
	<br />
	
	<p> <i> <strong> Images, Avatar and Quotes Rules </strong> </i> </p> 
	- <i> <b> It is forbidden to use racist or other offensive content as images, avatars or Quotes. <br />
	
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>