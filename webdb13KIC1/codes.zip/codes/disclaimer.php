<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<p style="h1"><Strong>Disclaimer</strong></p>

This disclaimer applies to:<br /><br />
	The owner: the owner of the website<br />
    Use: all possible actions on this website<br />
    You: The visitor of the website<br />
    Content: The content of this website<br /><br />

The following applies to the page you are currently viewing. By visiting this website, you automatically agree with our disclaimer.<br />
The content is composed by the owner with great care, however the owner accepts no liability for any inaccuracies displayed. <br />
The owner is not responsible for the content of linked files to other files not belonging to the content of this website.<br />
Unauthorized or improper use of (parts of) the content infringe intellectual property rights.<br />
Permission to use the displayed (parts of) the content in public places must be requested in writing to us. <br />
</body>
</html>
