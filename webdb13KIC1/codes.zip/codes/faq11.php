<h3 class="tablehead">
	Is it possible to contact a forum member without posting a message in the forums? 
</h3>
<!--content-->
<div>
	The only way is to send an email. The emails of all members are listed in the memberlist. <br />
	
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>