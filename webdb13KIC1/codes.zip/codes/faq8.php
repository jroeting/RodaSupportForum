<h3 class="tablehead">
	Can I use HTML codes in my discussion postings or can I stylize some of my text?
</h3>
<!-- content-->
<div>
	You can use HTML codes in your posts, but only where necessary. It is approved to use tags like &#60;strong&#62;&#60;/strong&#62; or &#60;em&#62;&#60;/em&#62; to highlight your texts.
    Posts with excessive use of HTML, will be removed. <br />
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>