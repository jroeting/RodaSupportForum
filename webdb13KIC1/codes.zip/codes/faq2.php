<h3 class="tablehead">
	How do I log into the forums?
</h3>
<!-- content -->
<div>
	Simply click on the "login" on the top right corner of the forum page next to "register" and fill in your login data. <br />	
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>
