<h3 class="tablehead">
	How do I get to know more about the members who have posted in the forums?
</h3>
<!-- content -->
<div>
	To know more about the members, you can click on their names at the posts. <br />
	It will lead you to their profiles. An other option is to go to the memberlist, located on the red main menu. <br />
	<br />
	<br />
	<a href="index.php?content=faq"> Go Back </a>
</div>